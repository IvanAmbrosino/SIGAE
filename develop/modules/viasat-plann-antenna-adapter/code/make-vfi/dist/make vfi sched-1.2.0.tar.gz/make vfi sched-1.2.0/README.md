# Crea el archivo VFI 

Recibe como parametros los datos de planificacion y devuelve un archivo de planificacion para el formato VFI segun el documento https://cgss-managment-tools.et.conae.gov.ar/dmsf/files/1444/view

# Consultar estado en la antena.

* Se puede consultar el estado del Schedule de la antena?
* Si no se puede consultar, usar redis para tener local lo enviado cuando tengo confirmacion del envio del rciSched?
* Buscar por scp/ftp el importSched.done?